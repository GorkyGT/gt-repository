/**Sistema de ventas de componentes tecnologicos mayoristas a nivel nacional
 * @group Grupo_4
 * @authors Lima_Anthony, Arias Mario, Villarreal Gorky, Minuche Damián
 * @version 1.0  
 */
import java.io.IOException;
import Vistas.frmPrincipal;

public class Inicio {
	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args){
		frmPrincipal frm =new frmPrincipal();
		frm.setVisible(true);
	}

}
